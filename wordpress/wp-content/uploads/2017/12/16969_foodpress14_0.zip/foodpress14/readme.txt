------------------------------------------------------
FoodPress - WordPress Restaurant Menu Management Plugin
------------------------------------------------------

Thank you very much for your purchase of foodpress plugin. 

Plugin Support: http://myfoodpress.com/support/
Codecanyon Message Board: http://codecanyon.net/item/foodpress-restaurant-menu-reservation-plugin/6480595/comments

We hope you enjoy our efforts to make your restaurant menu look beautiful!

Best,

Michael & Ashan - FoodPress creators

